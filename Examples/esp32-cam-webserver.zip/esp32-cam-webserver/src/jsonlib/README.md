# A lightweight JSON library 

https://github.com/wyolum/jsonlib

I dont want to use the 'goto' library for this, ArduinoJSON, something lighter and easier to include seemed appropriate
